# Waifu Market — Web App

## Deploy on Render
1. Create a **Web Service** on render.com
2. Upload these files
3. Build command: `pip install -r requirements.txt`
4. Start command: `python app.py`
5. Either set env vars from `.env.example` OR use the `/setup` page

## First-time Setup (easiest)
1. Deploy on Render (env vars are optional)
2. Open the web URL → you'll be redirected to `/setup`
3. Fill in MONGO_URI, BOT_TOKEN, OWNER_ID
4. For Bot API: run `/api` in your Telegram bot to generate a key
5. Paste the bot's Render URL + that key

## Health Check (for Uptime Robot)
- URL: https://your-web.onrender.com/healthz  → {"status":"ok"}

## Connecting Bot ↔ Web
- Set `MARKET_URL` in the bot to this web app's URL
- Set `BOT_API_URL` + `BOT_API_KEY` in the web to the bot's URL + API key
