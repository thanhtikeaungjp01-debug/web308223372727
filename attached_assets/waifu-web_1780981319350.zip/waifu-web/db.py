"""
web/db.py — Sync database layer for the web marketplace.
Uses pymongo if MONGO_URI is set, otherwise a JSON-file store.
Config is read dynamically from config_store (env vars > data/config.json).
"""
from __future__ import annotations
import json
import os
import time
import uuid
from pathlib import Path

# ── rarity constants ──────────────────────────────────────────────────────────

RARITY_VALUE: dict[str, int] = {
    "⛩️ Universal":       11,
    "🌸 Special Edition": 10,
    "🪞 Supreme":          9,
    "✨ Cataphract":       8,
    "⚡️ CrossVerse":       7,
    "⚜️ Divine":           6,
    "💮 Mythical":         5,
    "🟡 Legend":           4,
    "🟤 Medium":           3,
    "🔵 Rare":             2,
    "⚪ Common":           1,
}

RARITY_SELL_PRICE: dict[str, int] = {
    "⛩️ Universal":       300010,
    "🌸 Special Edition":  70040,
    "🪞 Supreme":          20060,
    "✨ Cataphract":       10030,
    "⚡️ CrossVerse":        2750,
    "⚜️ Divine":            1390,
    "💮 Mythical":           760,
    "🟡 Legend":             273,
    "🟤 Medium":             110,
    "🔵 Rare":                30,
    "⚪ Common":              15,
}

MAX_SELLABLE_VALUE = 7
LIST_FEE           = 10


def is_sellable(rarity: str) -> bool:
    return RARITY_VALUE.get(rarity, 0) <= MAX_SELLABLE_VALUE


def usd(cents: int) -> str:
    return f"${cents / 100:.2f}"


def _ago(ts: float) -> str:
    delta = int(time.time() - ts)
    if delta < 60:    return "just now"
    if delta < 3600:  return f"{delta // 60}m ago"
    if delta < 86400: return f"{delta // 3600}h ago"
    return f"{delta // 86400}d ago"


# ── MongoDB backend ────────────────────────────────────────────────────────────

class MongoWebDB:
    def __init__(self, mongo_uri: str, db_name: str):
        from pymongo import MongoClient, DESCENDING
        self._DESC = DESCENDING
        self._client = MongoClient(mongo_uri, serverSelectionTimeoutMS=6000)
        mdb = self._client[db_name]
        self._users    = mdb["users"]
        self._market   = mdb["market_listings"]
        self._chars    = mdb["anime_characters"]
        self._settings = mdb["bot_settings"]
        self._tx       = mdb["transactions"]
        self._client.admin.command("ping")

    def get_user(self, user_id: int):
        return self._users.find_one({"id": user_id})

    def ensure_user(self, user_id: int, first_name: str, username: str):
        self._users.update_one(
            {"id": user_id},
            {"$setOnInsert": {
                "id": user_id, "coins": 0, "characters": [],
                "favorites": [], "xp": 0, "wins": 0,
            }},
            upsert=True,
        )
        self._users.update_one(
            {"id": user_id},
            {"$set": {"first_name": first_name, "username": username}},
        )
        return self._users.find_one({"id": user_id})

    def get_balance(self, user_id: int) -> int:
        doc = self._users.find_one({"id": user_id}, {"coins": 1})
        return (doc or {}).get("coins", 0)

    def add_coins(self, user_id: int, delta: int) -> int:
        doc = self._users.find_one_and_update(
            {"id": user_id},
            {"$inc": {"coins": delta}},
            return_document=True,
        )
        return (doc or {}).get("coins", 0)

    def get_harem(self, user_id: int) -> list:
        doc = self._users.find_one({"id": user_id}, {"characters": 1})
        return (doc or {}).get("characters", [])

    def remove_char(self, user_id: int, char_id: str):
        doc = self._users.find_one({"id": user_id}, {"characters": 1})
        if not doc:
            return None
        chars = doc.get("characters", [])
        found = next((c for c in chars if str(c.get("id")) == str(char_id)), None)
        if not found:
            return None
        idx = next(i for i, c in enumerate(chars) if str(c.get("id")) == str(char_id))
        chars.pop(idx)
        self._users.update_one({"id": user_id}, {"$set": {"characters": chars}})
        return found

    def add_char(self, user_id: int, char: dict):
        self._users.update_one({"id": user_id}, {"$push": {"characters": char}})

    def find_user_by_username(self, username: str):
        username = username.lstrip("@")
        return self._users.find_one({"username": {"$regex": f"^{username}$", "$options": "i"}})

    def get_listings(self, skip=0, limit=20, rarity=None, search=None) -> list:
        filt: dict = {}
        if rarity:
            filt["char.rarity"] = rarity
        if search:
            filt["$or"] = [
                {"char.name":  {"$regex": search, "$options": "i"}},
                {"char.anime": {"$regex": search, "$options": "i"}},
            ]
        return list(self._market.find(filt).sort("listed_at", self._DESC).skip(skip).limit(limit))

    def count_listings(self, rarity=None, search=None) -> int:
        filt: dict = {}
        if rarity:
            filt["char.rarity"] = rarity
        if search:
            filt["$or"] = [
                {"char.name":  {"$regex": search, "$options": "i"}},
                {"char.anime": {"$regex": search, "$options": "i"}},
            ]
        return self._market.count_documents(filt)

    def get_listing(self, listing_id: str):
        from bson import ObjectId
        try:
            return self._market.find_one({"_id": ObjectId(listing_id)})
        except Exception:
            return self._market.find_one({"_id": listing_id})

    def add_listing(self, seller_id, seller_name, char, price) -> str:
        result = self._market.insert_one({
            "seller_id":   seller_id,
            "seller_name": seller_name,
            "char_id":     str(char["id"]),
            "char":        char,
            "price":       price,
            "listed_at":   time.time(),
        })
        return str(result.inserted_id)

    def _delete_listing_raw(self, listing_id: str):
        from bson import ObjectId
        try:
            return self._market.find_one_and_delete({"_id": ObjectId(listing_id)})
        except Exception:
            return self._market.find_one_and_delete({"_id": listing_id})

    def get_user_listings(self, user_id: int) -> list:
        return list(self._market.find({"seller_id": user_id}).sort("listed_at", self._DESC))

    def delist_listing(self, listing_id: str, by_admin=False):
        listing = self._delete_listing_raw(listing_id)
        if listing:
            self.add_char(listing["seller_id"], listing["char"])
            self.log_transaction("delist", listing["seller_id"], listing["seller_id"], 0,
                                 {"char": listing["char"], "by_admin": by_admin, "listing_id": listing_id})
        return listing

    def buy_listing(self, listing_id: str, buyer_id: int, buyer_name: str) -> dict:
        from bson import ObjectId
        try:
            listing = self._market.find_one({"_id": ObjectId(listing_id)})
        except Exception:
            return {"ok": False, "error": "Invalid listing ID"}
        if not listing:
            return {"ok": False, "error": "Listing not found"}
        if listing["seller_id"] == buyer_id:
            return {"ok": False, "error": "Cannot buy your own listing"}
        price = listing["price"]
        buyer = self._users.find_one({"id": buyer_id})
        if not buyer or buyer.get("coins", 0) < price:
            return {"ok": False, "error": f"Insufficient balance. Need {usd(price)}"}
        self._users.update_one({"id": buyer_id},             {"$inc": {"coins": -price}})
        self._users.update_one({"id": listing["seller_id"]}, {"$inc": {"coins":  price}})
        self.add_char(buyer_id, listing["char"])
        self._market.delete_one({"_id": ObjectId(listing_id)})
        self.log_transaction("buy", buyer_id, listing["seller_id"], price, {
            "char": listing["char"], "listing_id": listing_id,
            "buyer_name": buyer_name, "seller_name": listing["seller_name"],
        })
        return {"ok": True, "char": listing["char"], "price": price}

    def transfer_coins(self, from_id, to_id, amount, from_name="", to_name="") -> dict:
        if amount <= 0:
            return {"ok": False, "error": "Amount must be positive"}
        if from_id == to_id:
            return {"ok": False, "error": "Cannot transfer to yourself"}
        if self.get_balance(from_id) < amount:
            return {"ok": False, "error": "Insufficient balance"}
        if not self._users.find_one({"id": to_id}):
            return {"ok": False, "error": "Recipient not found"}
        self._users.update_one({"id": from_id}, {"$inc": {"coins": -amount}})
        self._users.update_one({"id": to_id},   {"$inc": {"coins":  amount}})
        self.log_transaction("transfer", from_id, to_id, amount,
                             {"from_name": from_name, "to_name": to_name})
        return {"ok": True, "new_balance": self.get_balance(from_id)}

    def log_transaction(self, tx_type, from_id, to_id, amount, details=None):
        self._tx.insert_one({
            "type":    tx_type,
            "from_id": from_id,
            "to_id":   to_id,
            "amount":  amount,
            "details": details or {},
            "ts":      time.time(),
        })

    def get_transactions(self, user_id: int, limit=30) -> list:
        return list(
            self._tx.find({"$or": [{"from_id": user_id}, {"to_id": user_id}]})
            .sort("ts", self._DESC).limit(limit)
        )

    def verify_api_key(self, key: str) -> bool:
        doc  = self._settings.find_one({"_id": "web_api_keys"})
        keys = (doc or {}).get("keys", [])
        return any(k["key"] == key for k in keys)

    def all_listings(self) -> list:
        return list(self._market.find().sort("listed_at", self._DESC))

    def top_users(self, limit=50) -> list:
        return list(
            self._users.find(
                {},
                {"id": 1, "first_name": 1, "username": 1, "coins": 1, "characters": 1},
            ).sort("coins", self._DESC).limit(limit)
        )


# ── JSON-file fallback ────────────────────────────────────────────────────────

class LocalWebDB:
    _DIR = Path("data")

    def __init__(self):
        self._DIR.mkdir(exist_ok=True)
        self._cache: dict[str, dict] = {}

    def _load(self, name: str) -> dict:
        if name not in self._cache:
            p = self._DIR / f"{name}.json"
            self._cache[name] = json.loads(p.read_text()) if p.exists() else {}
        return self._cache[name]

    def _save(self, name: str):
        p = self._DIR / f"{name}.json"
        p.write_text(json.dumps(self._cache[name], indent=2, default=str))

    def _u(self, name: str, data: dict):
        self._cache[name] = data
        self._save(name)

    def get_user(self, user_id: int):
        return self._load("users").get(str(user_id))

    def ensure_user(self, user_id: int, first_name: str, username: str):
        users = self._load("users")
        k = str(user_id)
        if k not in users:
            users[k] = {"id": user_id, "coins": 0, "characters": [], "favorites": [], "xp": 0, "wins": 0}
        users[k].update({"first_name": first_name, "username": username})
        self._u("users", users)
        return users[k]

    def get_balance(self, user_id: int) -> int:
        return (self.get_user(user_id) or {}).get("coins", 0)

    def add_coins(self, user_id: int, delta: int) -> int:
        users = self._load("users")
        k = str(user_id)
        if k not in users:
            users[k] = {"id": user_id, "coins": 0, "characters": []}
        users[k]["coins"] = users[k].get("coins", 0) + delta
        self._u("users", users)
        return users[k]["coins"]

    def get_harem(self, user_id: int) -> list:
        return (self.get_user(user_id) or {}).get("characters", [])

    def remove_char(self, user_id: int, char_id: str):
        users = self._load("users")
        k = str(user_id)
        if k not in users:
            return None
        chars = users[k].get("characters", [])
        found = next((c for c in chars if str(c.get("id")) == str(char_id)), None)
        if not found:
            return None
        idx = next(i for i, c in enumerate(chars) if str(c.get("id")) == str(char_id))
        chars.pop(idx)
        users[k]["characters"] = chars
        self._u("users", users)
        return found

    def add_char(self, user_id: int, char: dict):
        users = self._load("users")
        k = str(user_id)
        if k not in users:
            users[k] = {"id": user_id, "coins": 0, "characters": []}
        users[k].setdefault("characters", []).append(char)
        self._u("users", users)

    def find_user_by_username(self, username: str):
        username = username.lstrip("@").lower()
        for u in self._load("users").values():
            if (u.get("username") or "").lower() == username:
                return u
        return None

    def _all_listings(self) -> list:
        items = list(self._load("market").values())
        items.sort(key=lambda x: x.get("listed_at", 0), reverse=True)
        return items

    def get_listings(self, skip=0, limit=20, rarity=None, search=None) -> list:
        items = self._all_listings()
        if rarity:
            items = [i for i in items if i.get("char", {}).get("rarity") == rarity]
        if search:
            s = search.lower()
            items = [i for i in items if
                     s in i.get("char", {}).get("name",  "").lower() or
                     s in i.get("char", {}).get("anime", "").lower()]
        return items[skip:skip + limit]

    def count_listings(self, rarity=None, search=None) -> int:
        return len(self.get_listings(0, 999999, rarity, search))

    def get_listing(self, listing_id: str):
        return self._load("market").get(listing_id)

    def add_listing(self, seller_id, seller_name, char, price) -> str:
        market = self._load("market")
        lid    = uuid.uuid4().hex
        market[lid] = {
            "_id": lid, "seller_id": seller_id, "seller_name": seller_name,
            "char_id": str(char["id"]), "char": char,
            "price": price, "listed_at": time.time(),
        }
        self._u("market", market)
        return lid

    def _pop_listing(self, listing_id: str):
        market = self._load("market")
        item   = market.pop(listing_id, None)
        if item:
            self._u("market", market)
        return item

    def get_user_listings(self, user_id: int) -> list:
        return sorted(
            [v for v in self._load("market").values() if v.get("seller_id") == user_id],
            key=lambda x: x.get("listed_at", 0), reverse=True,
        )

    def delist_listing(self, listing_id: str, by_admin=False):
        listing = self._pop_listing(listing_id)
        if listing:
            self.add_char(listing["seller_id"], listing["char"])
            self.log_transaction("delist", listing["seller_id"], listing["seller_id"], 0,
                                 {"char": listing["char"], "by_admin": by_admin})
        return listing

    def buy_listing(self, listing_id: str, buyer_id: int, buyer_name: str) -> dict:
        listing = self.get_listing(listing_id)
        if not listing:
            return {"ok": False, "error": "Listing not found"}
        if listing["seller_id"] == buyer_id:
            return {"ok": False, "error": "Cannot buy your own listing"}
        price = listing["price"]
        if self.get_balance(buyer_id) < price:
            return {"ok": False, "error": f"Insufficient balance. Need {usd(price)}"}
        self.add_coins(buyer_id, -price)
        self.add_coins(listing["seller_id"], price)
        self.add_char(buyer_id, listing["char"])
        self._pop_listing(listing_id)
        self.log_transaction("buy", buyer_id, listing["seller_id"], price, {
            "char": listing["char"], "listing_id": listing_id,
            "buyer_name": buyer_name, "seller_name": listing["seller_name"],
        })
        return {"ok": True, "char": listing["char"], "price": price}

    def transfer_coins(self, from_id, to_id, amount, from_name="", to_name="") -> dict:
        if amount <= 0:
            return {"ok": False, "error": "Amount must be positive"}
        if from_id == to_id:
            return {"ok": False, "error": "Cannot transfer to yourself"}
        if self.get_balance(from_id) < amount:
            return {"ok": False, "error": "Insufficient balance"}
        if not self.get_user(to_id):
            return {"ok": False, "error": "Recipient not found"}
        self.add_coins(from_id, -amount)
        self.add_coins(to_id,    amount)
        self.log_transaction("transfer", from_id, to_id, amount,
                             {"from_name": from_name, "to_name": to_name})
        return {"ok": True, "new_balance": self.get_balance(from_id)}

    def log_transaction(self, tx_type, from_id, to_id, amount, details=None):
        txs = self._load("transactions")
        tid = uuid.uuid4().hex
        txs[tid] = {"id": tid, "type": tx_type, "from_id": from_id, "to_id": to_id,
                    "amount": amount, "details": details or {}, "ts": time.time()}
        self._u("transactions", txs)

    def get_transactions(self, user_id: int, limit=30) -> list:
        txs = self._load("transactions")
        items = [v for v in txs.values()
                 if v.get("from_id") == user_id or v.get("to_id") == user_id]
        items.sort(key=lambda x: x.get("ts", 0), reverse=True)
        return items[:limit]

    def verify_api_key(self, key: str) -> bool:
        settings = self._load("settings")
        keys     = settings.get("web_api_keys", {}).get("keys", [])
        return any(k["key"] == key for k in keys)

    def all_listings(self) -> list:
        return self._all_listings()

    def top_users(self, limit=50) -> list:
        items = list(self._load("users").values())
        items.sort(key=lambda x: x.get("coins", 0), reverse=True)
        return items[:limit]


# ── factory ───────────────────────────────────────────────────────────────────

_db: MongoWebDB | LocalWebDB | None = None


def reset_db() -> None:
    """Force the next get_db() call to create a fresh connection."""
    global _db
    _db = None


def get_db() -> MongoWebDB | LocalWebDB:
    global _db
    if _db is None:
        try:
            from web.config_store import get as _cfg
        except ModuleNotFoundError:
            from config_store import get as _cfg  # type: ignore
        mongo_uri = _cfg("MONGO_URI")
        db_name   = _cfg("DB_NAME", "waifu_bot")
        if mongo_uri:
            try:
                _db = MongoWebDB(mongo_uri, db_name)
                print("[WebDB] Connected to MongoDB ✓")
            except Exception as e:
                print(f"[WebDB] MongoDB failed ({e}) — using local JSON store")
                _db = LocalWebDB()
        else:
            print("[WebDB] No MONGO_URI — using local JSON store")
            _db = LocalWebDB()
    return _db
