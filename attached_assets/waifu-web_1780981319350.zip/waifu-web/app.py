"""
web/app.py — Waifu Market standalone web application.
Run: python web/app.py  (or python -m web.app)
"""
from __future__ import annotations
import io
import os
import time
from functools import lru_cache

import requests as _req
from flask import (Flask, render_template, request, session, redirect,
                   url_for, jsonify, send_file, abort)

try:
    from web.db          import get_db, reset_db, usd, is_sellable, RARITY_VALUE, _ago, LIST_FEE
    from web.auth        import verify_telegram_login, set_bot_token, login_required, api_login_required
    from web.config_store import get as _cfg, get_int as _cfg_int, save as _cfg_save, \
                                  reload as _cfg_reload, is_configured, all_config
except ModuleNotFoundError:
    from db          import get_db, reset_db, usd, is_sellable, RARITY_VALUE, _ago, LIST_FEE  # type: ignore
    from auth        import verify_telegram_login, set_bot_token, login_required, api_login_required  # type: ignore
    from config_store import get as _cfg, get_int as _cfg_int, save as _cfg_save, \
                                  reload as _cfg_reload, is_configured, all_config  # type: ignore

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("SESSION_SECRET", os.urandom(32))
app.permanent_session_lifetime = 60 * 60 * 24 * 30


# ── dynamic config helpers (read fresh on every call) ─────────────────────────

def _bot_token()    -> str:  return _cfg("BOT_TOKEN")
def _bot_username() -> str:  return _cfg("BOT_USERNAME").lstrip("@")
def _owner_id()     -> int:  return _cfg_int("OWNER_ID")
def _bot_api_url()  -> str:  return _cfg("BOT_API_URL").rstrip("/")
def _bot_api_key()  -> str:  return _cfg("BOT_API_KEY")

def _refresh_auth():
    """Re-initialise the Telegram login verifier whenever BOT_TOKEN changes."""
    set_bot_token(_bot_token())

_refresh_auth()


# ── helpers ───────────────────────────────────────────────────────────────────

def current_user() -> dict | None:
    if "user_id" not in session:
        return None
    return {
        "id":         session["user_id"],
        "first_name": session.get("first_name", ""),
        "username":   session.get("username",   ""),
        "photo_url":  session.get("photo_url",  ""),
    }


def is_owner() -> bool:
    u  = current_user()
    oid = _owner_id()
    return bool(u and oid and u["id"] == oid)


def _check_api_key() -> bool:
    auth = request.headers.get("Authorization", "")
    key  = auth[7:].strip() if auth.startswith("Bearer ") else request.args.get("api_key", "")
    return bool(key and get_db().verify_api_key(key))


@lru_cache(maxsize=1024)
def _tg_file_url(file_id: str) -> str | None:
    token = _bot_token()
    if not token:
        return None
    try:
        r = _req.get(
            f"https://api.telegram.org/bot{token}/getFile",
            params={"file_id": file_id}, timeout=6,
        )
        d = r.json()
        if d.get("ok"):
            return f"https://api.telegram.org/file/bot{token}/{d['result']['file_path']}"
    except Exception:
        pass
    return None


def char_img_url(img_url: str) -> str:
    if not img_url:
        return url_for("static", filename="img/no_image.png")
    if img_url.startswith("http"):
        return img_url
    return url_for("proxy_image", file_id=img_url)


def _resolve_user_name(db, user_id) -> str:
    if not user_id:
        return ""
    try:
        doc = db.get_user(int(user_id))
        if doc:
            name  = doc.get("first_name") or doc.get("username") or ""
            uname = doc.get("username", "")
            return f"{name} (@{uname})" if uname and name and name != uname else (name or uname or str(user_id))
    except Exception:
        pass
    return str(user_id)


def _fmt_listing(lst: dict) -> dict:
    lst = dict(lst)
    lst["_id_str"]   = str(lst.get("_id", lst.get("id", "")))
    lst["price_str"] = usd(lst.get("price", 0))
    lst["ago"]       = _ago(lst.get("listed_at", 0))
    char = lst.get("char", {})
    lst["char_img"]  = char_img_url(char.get("img_url", ""))
    return lst


# ── before_request: redirect to /setup if not configured ─────────────────────

@app.before_request
def _check_setup():
    exempt = {"setup", "static"}
    if request.endpoint in exempt:
        return
    if not is_configured():
        return redirect(url_for("setup"))


# ── image proxy ───────────────────────────────────────────────────────────────

@app.route("/img/<path:file_id>")
def proxy_image(file_id):
    url = _tg_file_url(file_id)
    if not url:
        abort(404)
    try:
        r  = _req.get(url, timeout=12, stream=True)
        ct = r.headers.get("Content-Type", "image/jpeg")
        return send_file(io.BytesIO(r.content), mimetype=ct)
    except Exception:
        abort(404)


# ── setup wizard ──────────────────────────────────────────────────────────────

@app.route("/setup", methods=["GET", "POST"])
def setup():
    configured = is_configured()
    if configured and not is_owner():
        return redirect(url_for("market"))

    error   = None
    success = None

    if request.method == "POST":
        fields = ["MONGO_URI", "BOT_TOKEN", "BOT_USERNAME",
                  "OWNER_ID", "DB_NAME", "BOT_API_URL", "BOT_API_KEY"]
        data = {k: request.form.get(k, "").strip() for k in fields}

        if not data["MONGO_URI"] or not data["BOT_TOKEN"] or not data["OWNER_ID"]:
            error = "MONGO_URI, BOT_TOKEN and OWNER_ID are required."
        else:
            _cfg_save({k: v for k, v in data.items() if v})
            _cfg_reload()
            reset_db()
            _refresh_auth()
            return redirect(url_for("market"))

    return render_template(
        "setup.html",
        user=current_user(),
        config=all_config(),
        bot_token_set=bool(_cfg("BOT_TOKEN")),
        mongo_set=bool(_cfg("MONGO_URI")),
        configured=configured,
        error=error,
        success=success,
    )


# ── auth ──────────────────────────────────────────────────────────────────────

@app.route("/auth/bot")
def bot_auth():
    token    = request.args.get("token", "").strip()
    next_url = request.args.get("next", "/market")
    if not token:
        return redirect(url_for("index") + "?error=1")

    try:
        from waifu.webtoken import consume_token
    except ImportError:
        import sys, os as _os
        sys.path.insert(0, _os.path.dirname(_os.path.dirname(__file__)))
        try:
            from waifu.webtoken import consume_token  # type: ignore
        except ImportError:
            from webtoken import consume_token  # type: ignore

    doc = consume_token(token)
    if not doc:
        return redirect(url_for("index") + "?error=expired")

    uid   = int(doc["user_id"])
    fname = doc.get("first_name", "")
    uname = doc.get("username",   "")
    get_db().ensure_user(uid, fname, uname)
    session.permanent     = True
    session["user_id"]    = uid
    session["first_name"] = fname
    session["username"]   = uname
    session["photo_url"]  = ""
    return redirect(next_url)


@app.route("/auth/telegram")
def telegram_auth():
    data = dict(request.args)
    if not verify_telegram_login(data):
        return redirect(url_for("index") + "?error=1")
    uid   = int(data["id"])
    fname = data.get("first_name", "")
    uname = data.get("username",   "")
    get_db().ensure_user(uid, fname, uname)
    session.permanent     = True
    session["user_id"]    = uid
    session["first_name"] = fname
    session["username"]   = uname
    session["photo_url"]  = data.get("photo_url", "")
    return redirect(data.get("next") or url_for("market"))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


# ── pages ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    user = current_user()
    if user:
        return redirect(url_for("market"))
    return render_template("index.html", bot_username=_bot_username(), user=None)


@app.route("/market")
def market():
    db       = get_db()
    page     = max(1, int(request.args.get("page", 1)))
    per_page = 20
    rarity   = request.args.get("rarity", "").strip() or None
    search   = request.args.get("q",      "").strip() or None
    skip     = (page - 1) * per_page
    total    = db.count_listings(rarity, search)
    listings = [_fmt_listing(l) for l in db.get_listings(skip, per_page, rarity, search)]
    pages    = max(1, (total + per_page - 1) // per_page)
    rarities = list(RARITY_VALUE.keys())
    return render_template(
        "market.html",
        user=current_user(), listings=listings,
        page=page, pages=pages, total=total,
        rarity=rarity or "", search=search or "",
        rarities=rarities, is_owner=is_owner(),
    )


@app.route("/harem")
@login_required
def harem():
    db  = get_db()
    uid = session["user_id"]
    raw = db.get_harem(uid)
    seen: dict[str, dict] = {}
    for c in raw:
        cid = str(c.get("id"))
        if cid not in seen:
            seen[cid] = dict(c)
            seen[cid]["count"] = 0
            seen[cid]["img"]   = char_img_url(c.get("img_url", ""))
        seen[cid]["count"] += 1
    for c in seen.values():
        c["sellable"]   = is_sellable(c.get("rarity", ""))
        c["rarity_val"] = RARITY_VALUE.get(c.get("rarity", ""), 0)
    char_list   = sorted(seen.values(), key=lambda x: x["rarity_val"], reverse=True)
    my_listings = [_fmt_listing(l) for l in db.get_user_listings(uid)]
    return render_template("harem.html",
                           user=current_user(), chars=char_list,
                           my_listings=my_listings, usd=usd)


@app.route("/wallet")
@login_required
def wallet():
    db  = get_db()
    uid = session["user_id"]
    bal = db.get_balance(uid)
    txs = db.get_transactions(uid, 60)
    for tx in txs:
        tx["_id_str"]    = str(tx.get("_id", tx.get("id", "")))
        tx["ago"]        = _ago(tx.get("ts", 0))
        tx["amount_str"] = usd(tx.get("amount", 0))
        tx["direction"]  = "out" if tx.get("from_id") == uid else "in"
        tx_type = tx.get("type", "")
        det = tx.get("details", {})
        if tx_type == "buy":
            tx["label"] = "🛒 Bought" if tx["direction"] == "out" else "💰 Sold"
        elif tx_type == "transfer":
            tx["label"] = "📤 Sent"   if tx["direction"] == "out" else "📥 Received"
        elif tx_type == "sell_list":
            tx["label"] = "🏷️ Listing fee"
        elif tx_type == "delist":
            tx["label"] = "↩️ Delisted"
        else:
            tx["label"] = tx_type.replace("_", " ").title()
        from_id   = tx.get("from_id")
        to_id     = tx.get("to_id")
        from_name = (det.get("from_name") or det.get("buyer_name")  or
                     _resolve_user_name(db, from_id) if from_id else "")
        to_name   = (det.get("to_name")   or det.get("seller_name") or
                     _resolve_user_name(db, to_id)   if to_id   else "")
        if tx["direction"] == "out":
            tx["party_label"] = "To";   tx["party_name"] = to_name;   tx["party_id"] = to_id
        else:
            tx["party_label"] = "From"; tx["party_name"] = from_name; tx["party_id"] = from_id
        char = det.get("char")
        tx["char_name"]   = char.get("name",   "") if char else ""
        tx["char_rarity"] = char.get("rarity", "") if char else ""
    return render_template("wallet.html",
                           user=current_user(), uid=uid,
                           balance=bal, balance_str=usd(bal), txs=txs)


@app.route("/admin")
def admin():
    if not is_owner():
        abort(403)
    db       = get_db()
    listings = [_fmt_listing(l) for l in db.all_listings()]
    users    = db.top_users(30)
    for u in users:
        u["balance_str"] = usd(u.get("coins", 0))
        u["char_count"]  = len(u.get("characters", []))
    return render_template("admin.html",
                           user=current_user(), listings=listings,
                           top_users=users, total=len(listings),
                           config=all_config(),
                           bot_api_url=_bot_api_url(),
                           bot_username=_bot_username())


# ── API: bot status proxy ─────────────────────────────────────────────────────

@app.route("/api/bot-status")
def api_bot_status():
    if not is_owner():
        return jsonify({"ok": False, "error": "Unauthorized"}), 401
    api_url = _bot_api_url()
    api_key = _bot_api_key()
    if not api_url:
        return jsonify({"ok": False, "error": "BOT_API_URL not configured"})
    try:
        r = _req.get(
            f"{api_url}/api/stats",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=5,
        )
        return jsonify(r.json())
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


# ── API: save settings (admin) ────────────────────────────────────────────────

@app.route("/api/admin/settings", methods=["POST"])
def api_admin_settings():
    if not is_owner():
        return jsonify({"ok": False, "error": "Unauthorized"}), 401
    data   = request.get_json(force=True) or {}
    fields = ["BOT_USERNAME", "OWNER_ID", "DB_NAME",
              "BOT_API_URL", "BOT_API_KEY", "MARKET_URL",
              "SUPPORT_CHAT", "UPDATE_CHAT"]
    to_save = {k: str(data[k]).strip() for k in fields if k in data and str(data[k]).strip()}
    if not to_save:
        return jsonify({"ok": False, "error": "Nothing to save"})
    _cfg_save(to_save)
    _cfg_reload()
    return jsonify({"ok": True})


# ── API: sell ─────────────────────────────────────────────────────────────────

@app.route("/api/sell", methods=["POST"])
@api_login_required
def api_sell():
    db      = get_db()
    uid     = session["user_id"]
    data    = request.get_json(force=True) or {}
    char_id = str(data.get("char_id", "")).strip()
    try:
        price = int(data.get("price", 0))
    except (ValueError, TypeError):
        return jsonify({"ok": False, "error": "Invalid price"})
    if price < 1:
        return jsonify({"ok": False, "error": "Price must be at least $0.01 (1 cent)"})
    chars = db.get_harem(uid)
    char  = next((c for c in chars if str(c.get("id")) == char_id), None)
    if not char:
        return jsonify({"ok": False, "error": "Character not found in your harem"})
    if not is_sellable(char.get("rarity", "")):
        return jsonify({"ok": False, "error": "Only CrossVerse rarity and below can be listed"})
    if db.get_balance(uid) < LIST_FEE:
        return jsonify({"ok": False, "error": f"Need {usd(LIST_FEE)} listing fee"})
    removed = db.remove_char(uid, char_id)
    if not removed:
        return jsonify({"ok": False, "error": "Could not remove character — try again"})
    db.add_coins(uid, -LIST_FEE)
    seller_name = session.get("first_name", str(uid))
    lid = db.add_listing(uid, seller_name, char, price)
    db.log_transaction("sell_list", uid, uid, LIST_FEE,
                       {"char": char, "listing_id": lid, "price": price})
    return jsonify({"ok": True, "listing_id": lid,
                    "message": f"Listed {char.get('name')} for {usd(price)}"})


# ── API: buy ──────────────────────────────────────────────────────────────────

@app.route("/api/buy/<listing_id>", methods=["POST"])
@api_login_required
def api_buy(listing_id):
    uid    = session["user_id"]
    name   = session.get("first_name", str(uid))
    result = get_db().buy_listing(listing_id, uid, name)
    return jsonify(result)


# ── API: delist ───────────────────────────────────────────────────────────────

@app.route("/api/delist/<listing_id>", methods=["POST"])
@api_login_required
def api_delist(listing_id):
    db      = get_db()
    uid     = session["user_id"]
    listing = db.get_listing(listing_id)
    if not listing:
        return jsonify({"ok": False, "error": "Listing not found"})
    if listing.get("seller_id") != uid and not is_owner():
        return jsonify({"ok": False, "error": "Not your listing"})
    result = db.delist_listing(listing_id, by_admin=is_owner())
    return jsonify({"ok": bool(result)})


# ── API: user lookup ──────────────────────────────────────────────────────────

@app.route("/api/user-lookup")
@api_login_required
def api_user_lookup():
    q  = request.args.get("q", "").strip()
    db = get_db()
    if not q:
        return jsonify({"ok": False, "error": "Enter a Wallet ID or @username"})
    if q.lstrip("@").isdigit():
        uid = int(q.lstrip("@"))
        doc = db.get_user(uid)
    else:
        doc = db.find_user_by_username(q.lstrip("@"))
        uid = doc["id"] if doc else 0
    if not doc:
        return jsonify({"ok": False, "error": "User not found."})
    if doc.get("id") == session["user_id"] or uid == session["user_id"]:
        return jsonify({"ok": False, "error": "You can't send coins to yourself"})
    name  = doc.get("first_name", "") or doc.get("username", "") or str(uid)
    uname = doc.get("username", "")
    display = f"{name} (@{uname})" if uname and name and name != uname else name or str(uid)
    return jsonify({"ok": True, "user_id": uid, "display_name": display})


# ── API: transfer ─────────────────────────────────────────────────────────────

@app.route("/api/transfer", methods=["POST"])
@api_login_required
def api_transfer():
    db     = get_db()
    uid    = session["user_id"]
    data   = request.get_json(force=True) or {}
    to_val = str(data.get("to", "")).strip()
    try:
        amount = int(float(data.get("amount", 0)) * 100)
    except (ValueError, TypeError):
        return jsonify({"ok": False, "error": "Invalid amount"})
    if to_val.lstrip("@").isdigit():
        to_id  = int(to_val.lstrip("@"))
        to_doc = db.get_user(to_id)
    else:
        to_doc = db.find_user_by_username(to_val)
        to_id  = to_doc["id"] if to_doc else 0
    if not to_doc:
        return jsonify({"ok": False, "error": "User not found"})
    fname  = session.get("first_name", str(uid))
    result = db.transfer_coins(uid, to_id, amount,
                               from_name=fname,
                               to_name=to_doc.get("first_name", str(to_id)))
    if result.get("ok"):
        result["new_balance_str"] = usd(result.get("new_balance", 0))
    return jsonify(result)


# ── API: balance ──────────────────────────────────────────────────────────────

@app.route("/api/balance")
@api_login_required
def api_balance():
    bal = get_db().get_balance(session["user_id"])
    return jsonify({"ok": True, "balance": bal, "balance_str": usd(bal)})


# ── API: admin delist ─────────────────────────────────────────────────────────

@app.route("/api/admin/delist/<listing_id>", methods=["DELETE", "POST"])
def api_admin_delist(listing_id):
    if not (_check_api_key() or is_owner()):
        return jsonify({"ok": False, "error": "Unauthorized"}), 401
    result = get_db().delist_listing(listing_id, by_admin=True)
    return jsonify({"ok": bool(result)})


@app.route("/api/admin/listings")
def api_admin_listings():
    if not (_check_api_key() or is_owner()):
        return jsonify({"ok": False, "error": "Unauthorized"}), 401
    listings = [_fmt_listing(l) for l in get_db().all_listings()]
    return jsonify({"ok": True, "count": len(listings), "listings": listings})


# ── run ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port  = int(os.environ.get("WEB_PORT", os.environ.get("PORT", "5000")))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    print(f"🌸 Waifu Market running → http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", port=port, debug=debug, use_reloader=False)
