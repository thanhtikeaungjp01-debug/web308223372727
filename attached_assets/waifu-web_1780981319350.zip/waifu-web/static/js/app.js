/* ── Page loader ─────────────────────────────────────────────────────────── */
window.addEventListener('load', () => {
  const loader = document.getElementById('page-loader');
  if (loader) setTimeout(() => loader.classList.add('hidden'), 200);
});

/* ── Mobile nav toggle ───────────────────────────────────────────────────── */
const navToggle  = document.getElementById('navToggle');
const mobileMenu = document.getElementById('mobileMenu');
if (navToggle && mobileMenu) {
  navToggle.addEventListener('click', () => mobileMenu.classList.toggle('open'));
  document.addEventListener('click', e => {
    if (!navToggle.contains(e.target) && !mobileMenu.contains(e.target)) {
      mobileMenu.classList.remove('open');
    }
  });
}

/* ── Toast notifications ─────────────────────────────────────────────────── */
function showToast(msg, type = 'info', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

/* ── Modal helpers ───────────────────────────────────────────────────────── */
function showModal(id) {
  const el = document.getElementById(id);
  if (el) { el.style.display = 'flex'; document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) { el.style.display = 'none'; document.body.style.overflow = ''; }
}

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.style.display = 'none';
    document.body.style.overflow = '';
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay').forEach(m => {
      m.style.display = 'none';
    });
    document.body.style.overflow = '';
  }
});

/* ── Double-click / rapid-click lock ─────────────────────────────────────── *
 * Usage:
 *   btn.addEventListener('click', () => withLock(btn, async () => {
 *     // only runs if not already in progress
 *   }));
 * ─────────────────────────────────────────────────────────────────────────── */
async function withLock(btnOrKey, fn) {
  const key     = typeof btnOrKey === 'string' ? btnOrKey : btnOrKey;
  const btn     = typeof btnOrKey === 'object' ? btnOrKey : null;
  const dataKey = '__locked__';

  if (btn) {
    if (btn.dataset[dataKey]) return;      // already running → ignore click
    btn.dataset[dataKey] = '1';
    const origText = btn.textContent;
    const origDisabled = btn.disabled;
    btn.disabled = true;
    try {
      await fn({ origText, btn });
    } finally {
      delete btn.dataset[dataKey];
      btn.disabled = origDisabled;
    }
  } else {
    await fn({});
  }
}

/* ── API helpers ─────────────────────────────────────────────────────────── */
async function apiPost(url, body = {}) {
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (res.status === 401) return { ok: false, error: 'Not logged in — please refresh and login again.' };
    if (res.status === 403) return { ok: false, error: 'Permission denied.' };
    if (!res.ok && res.status >= 500) return { ok: false, error: `Server error (${res.status})` };
    return await res.json();
  } catch (err) {
    console.error('apiPost error:', err);
    return { ok: false, error: 'Network error — check your connection.' };
  }
}

async function apiGet(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    return await res.json();
  } catch (err) {
    return { ok: false, error: 'Network error' };
  }
}

/* ── Lazy-load images with fade-in ──────────────────────────────────────── */
document.querySelectorAll('.char-img').forEach(img => {
  img.style.opacity = '0';
  img.style.transition = 'opacity .3s';
  if (img.complete) {
    img.style.opacity = '1';
  } else {
    img.addEventListener('load',  () => { img.style.opacity = '1'; });
    img.addEventListener('error', () => { img.style.opacity = '1'; });
  }
});

/* ── Ad banner close ─────────────────────────────────────────────────────── */
const adCloseBtn = document.getElementById('adBannerClose');
if (adCloseBtn) {
  adCloseBtn.addEventListener('click', () => {
    const banner = document.getElementById('adBanner');
    if (banner) banner.style.display = 'none';
    sessionStorage.setItem('ad_closed', '1');
  });
  // Restore closed state within the session
  if (sessionStorage.getItem('ad_closed')) {
    const banner = document.getElementById('adBanner');
    if (banner) banner.style.display = 'none';
  }
}
